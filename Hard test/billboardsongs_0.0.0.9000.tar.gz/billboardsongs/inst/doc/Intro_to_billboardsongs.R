## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(billboardsongs)

## -----------------------------------------------------------------------------
random_song("Maroon 5")
spotify_playlist_url(year = "2015")
find_artist(title="Hymn for the Weekend")
song_lyrics(title="Treat You Better")
song_properties(track_name="The Nights")

