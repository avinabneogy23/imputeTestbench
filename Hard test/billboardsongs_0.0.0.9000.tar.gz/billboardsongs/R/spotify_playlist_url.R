#' Gives Billboard Year End Hot Singles Spotify playlist link for a particular year
#'
#' @param year The year for which the playlist is required
#' @param data The dataset defaukts to billboard::spotify_playlists
#'
#' @return The Sptify playlist url of Billboard Year End Hot Singles of a particular year
#' @export
#'
#' @examples spotify_playlist_url()
#' @examples spotify_playlist_url("2010")
#' @examples spotify_playlist_url(year = "2015")
#'
spotify_playlist_url<-function(year="2000",data = billboard::spotify_playlists)
{
  data<-data[data$year == year, ]
  cat(paste0("Spotify playlist url for ",year," is  https://open.spotify.com/playlist/",data$spotify_playlist))
}
