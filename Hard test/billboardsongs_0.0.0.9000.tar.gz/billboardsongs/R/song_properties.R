#' Gives properties of a song like Danceability and Energy
#'
#' @param track_name The name of the song for which one wants the properties
#' @param data The dataset defaukts to billboard::spotify_track_data
#'
#' @return The properties for a selected song
#' @export
#'
#' @examples song_properties()
#' @examples song_properties("Drive By")
#' @examples song_properties(track_name="The Nights")
song_properties<-function(track_name="Drive By",data = billboard::spotify_track_data)
{
  data<-data[data$track_name == track_name, ]
  cat(paste0("Danceability and Energy of ",track_name," are ",data$danceability," and ", data$energy))
}
