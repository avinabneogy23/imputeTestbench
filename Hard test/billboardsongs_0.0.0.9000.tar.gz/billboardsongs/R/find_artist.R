

#' Find the artist from the song title
#'
#' @param title The name of the song for which the artist is required
#' @param data The dataset defaukts to billboard::wiki_hot_100s
#'
#' @return The name of the artist who sung the song
#' @export
#'
#' @examples find_artist()
#' @examples find_artist("Adventure of a Lifetime")
#' @examples find_artist(title="Hymn for the Weekend")
find_artist<-function(title="On My Mind",data = billboard::wiki_hot_100s)
{
  data<-data[data$title == title, ]
  cat(paste0("The Artist for the song ",title," is ",data$artist))
}
