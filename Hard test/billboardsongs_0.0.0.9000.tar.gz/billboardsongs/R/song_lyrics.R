#' Shows the lyrics for a selected song
#'
#' @param title The name of the song for the the lyrics are required
#' @param data The dataset defaults to billboard::lyrics
#'
#' @return The lyrics for a selected song title
#' @export
#'
#' @examples song_lyrics()
#' @examples song_lyrics("Let Me Love You")
#' @examples song_lyrics(title="Treat You Better")

song_lyrics<-function(title="The A Team",data = billboard::lyrics)
{
  data<-data[data$title == title, ]
  cat(paste0("Lyrics of ",title," by ",data$artist," :", data$lyrics))
}
